<?php
class actividad{
 
    // database connection and table name
    private $conn;

    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // Resumen actividades
    function obtenerResumenActividades($idUsuario){


      // select all query
      $query = "SELECT ACT.idActividad, ACT.`nombreActividad`, ACT.`idSticker`,	
	                SUM(IF(UA.`idAccion` IS NULL, 0,ACC.`puntos`)) AS Puntos
                FROM usuarios U
                LEFT JOIN acciones ACC
	                ON ACC.idUnidadGestion= U.idUnidadGestion
                LEFT JOIN actividades ACT
	                ON ACT.idActividad = ACC.idActividad
                LEFT JOIN usuario_accion UA
	                ON UA.idUsuario = U.idUsuario
	                AND UA.idAccion = ACC.idAccion
                WHERE U.IdUsuario=$idUsuario
                GROUP BY ACT.idActividad
                ORDER BY ACT.Orden;";
      
      // prepare query statement
      $stmt = $this->conn->prepare($query);
 
      // execute query
      $stmt->execute();

      return $stmt;
    }    
}
