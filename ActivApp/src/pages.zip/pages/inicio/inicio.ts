import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-inicio',
  templateUrl: 'inicio.html'
})
export class inicioPage {

 
  imgCopa: string = "src/assets/images/s8l43ELwTZ2heUtyHQEW_trofeo.jpg";
  headerMisPuntos: string = "Tienes 700 puntos!"
  ranking: string = "Estás en el puesto 145"
  ultimosLogrosConseguidos: string = "Últimos logros conseguidos"
  proximosEventos: string = "Próximos eventos"

  logros_items: Array<any> = [];
  proximosEventos_items: Array<any> = [];
  frase: string = "Frase del día"
  fraseMotivacional: string = "'Cuanto más practico, más suerte tengo' Gary Player"


  constructor(public navCtrl: NavController) {

    this.logros_items.push({
      Logro: 'Fotosafari 1',
      Fecha: '10/10',
      Puntos: 50
    });
    this.logros_items.push({
      Logro: 'Fotosafari 2  ',
      Fecha: '20/10',
      Puntos: 30
    });
    this.logros_items.push({
      Logro: 'Solicitud Plan de Nutrición',
      Fecha: '10/11',
      Puntos: 40
    });

    this.proximosEventos_items.push({
      Logro: 'Charla Nutrición',
      Fecha: '03/12',
      Puntos: 50
    });

    this.proximosEventos_items.push({
      Logro: 'Bicicleteada familiar',
      Fecha: '08/12',
      Puntos: 80
    });

    this.proximosEventos_items.push({
      Logro: 'Maratón',
      Fecha: '12/12',
      Puntos: 60
    });

    }
  

    onLink(url: string) {
        window.open(url);
    }
}





